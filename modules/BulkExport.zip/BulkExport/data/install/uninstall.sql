SET foreign_key_checks = 0;
DROP TABLE `bulk_export`;
DROP TABLE `bulk_exporter`;
