<?php declare(strict_types=1);

namespace BulkExport\Form\Writer;

class FieldsJsonWriterConfigForm extends FieldsWriterConfigForm
{
}
